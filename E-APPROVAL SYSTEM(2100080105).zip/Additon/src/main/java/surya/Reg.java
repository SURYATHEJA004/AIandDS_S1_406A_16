package surya;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Reg")
public class Reg extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public Reg() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String in=request.getParameter("email");
		String dd=request.getParameter("password");
		String kd=request.getParameter("Name");
		Integer ke=(Integer)Integer.parseInt(request.getParameter("ID"));
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","suryaravi");
			PrintWriter pw =response.getWriter();
			
			
			PreparedStatement b =con.prepareStatement("insert into emp4 values(?,?,?,?,?,?)");
			
			b.setInt(1, ke);
			b.setString(2, in);
			b.setString(3, dd);
			b.setString(4, kd);
			b.setString (5,"x");
			b.setInt(6, '1');
			
			int bl= b.executeUpdate();
		  
		response.sendRedirect("user.html");
		         con.close();  
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
