package surya;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/sury")
public class sury extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public sury() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String in=request.getParameter("issue");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","suryaravi");
			PrintWriter pw =response.getWriter();
			HttpSession ses = request.getSession();
	    	
			
			PreparedStatement b =con.prepareStatement("update emp4 set issue=? where id=?");
			b.setString(1, in);
			b.setInt(2, (int)ses.getAttribute("id"));
			
			boolean bl=b.execute();
		  
		response.sendRedirect("user.html");
		         con.close();  
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
