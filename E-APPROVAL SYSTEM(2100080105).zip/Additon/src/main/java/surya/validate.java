package surya;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/validate")
public class validate extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public validate() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String s=request.getParameter("email");
		String q=request.getParameter("pwd");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","suryaravi");
			PrintWriter pw =response.getWriter();
			Statement st2=con.createStatement();
			
			ResultSet rs=st2.executeQuery("select * from emp4");
			int f=0;
			while(rs.next()) {
				System.out.println(rs.getString(2));
				System.out.println(rs.getString(3));
				 if(rs.getString(2).equals(s) && rs.getString(3).equals(q)) {
		            	f=1;
		            	HttpSession ses = request.getSession();
		            	ses.setAttribute("id",rs.getInt(1));
		            	response.sendRedirect("users.html");
		            	break;
		            } 
			}
			if(f==0) {
				response.sendRedirect("user.html");
			}
		            
			    
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
